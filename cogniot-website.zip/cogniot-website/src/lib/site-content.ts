import logoImageAsset from "@/assets/cogniot/cogniot-logo.png.asset.json";
import heroIotImageAsset from "@/assets/cogniot/hero-iot-product-development.jpg.asset.json";
import heroServicesImageAsset from "@/assets/cogniot/hero-it-services.jpg.asset.json";
import heroProjectsImageAsset from "@/assets/cogniot/hero-projects-accomplished.jpg.asset.json";
import labImageAsset from "@/assets/cogniot/engineering-lab.jpg.asset.json";
import aquaponicsImageAsset from "@/assets/cogniot/aquaponics-greenhouse.jpg.asset.json";
import healthcareImageAsset from "@/assets/cogniot/connected-healthcare.jpg.asset.json";
import aiSaasImageAsset from "@/assets/cogniot/ai-saas.jpg.asset.json";
import wirelessImageAsset from "@/assets/cogniot/5g-6g.jpg.asset.json";
import chipImageAsset from "@/assets/cogniot/digital-chip-design.jpg.asset.json";
import dpiitImageAsset from "@/assets/cogniot/dpiit-startup-certificate.jpg.asset.json";
import railwaysImageAsset from "@/assets/cogniot/indian-railways.png.asset.json";
import niotImageAsset from "@/assets/cogniot/niot.jpg.asset.json";
import tabcedcoImageAsset from "@/assets/cogniot/tabcedco.jpg.asset.json";
import kallarImageAsset from "@/assets/cogniot/kallar-reclamation-schools.png.asset.json";
import welfareImageAsset from "@/assets/cogniot/bc-mbc-minorities-welfare.png.asset.json";
import egitimImageAsset from "@/assets/cogniot/egitim-ventures.png.asset.json";
import caprimecImageAsset from "@/assets/cogniot/caprimec-technocrats.png.asset.json";

const logoImage = logoImageAsset.url;
const heroIotImage = heroIotImageAsset.url;
const heroServicesImage = heroServicesImageAsset.url;
const heroProjectsImage = heroProjectsImageAsset.url;
const labImage = labImageAsset.url;
const aquaponicsImage = aquaponicsImageAsset.url;
const healthcareImage = healthcareImageAsset.url;
const aiSaasImage = aiSaasImageAsset.url;
const wirelessImage = wirelessImageAsset.url;
const chipImage = chipImageAsset.url;
const dpiitImage = dpiitImageAsset.url;
const railwaysImage = railwaysImageAsset.url;
const niotImage = niotImageAsset.url;
const tabcedcoImage = tabcedcoImageAsset.url;
const kallarImage = kallarImageAsset.url;
const welfareImage = welfareImageAsset.url;
const egitimImage = egitimImageAsset.url;
const caprimecImage = caprimecImageAsset.url;

export const media = {
  logo: logoImage,
  heroIot: heroIotImage,
  heroServices: heroServicesImage,
  heroProjects: heroProjectsImage,
  engineeringLab: labImage,
  aquaponics: aquaponicsImage,
  healthcare: healthcareImage,
  aiSaas: aiSaasImage,
  wireless: wirelessImage,
  digitalChip: chipImage,
  dpiitCertificate: dpiitImage,
};

export const PRIMARY_NAV_LABELS = [
  "Home",
  "About Us",
  "Technologies",
  "Services",
  "Portfolio",
  "Careers",
  "Contact",
] as const;
export const CAROUSEL_INTERVAL_MS = 3000;

export const aboutNavigation = [
  { label: "Our Story", path: "/about/our-story" },
  { label: "Vision & Mission", path: "/about/vision-mission" },
  { label: "Leadership & Team", path: "/about/leadership-team" },
  { label: "Recognitions & Milestones", path: "/about/recognitions-milestones" },
  { label: "Our Clients & Partners", path: "/about/clients-partners" },
] as const;

export const technologyNavigation = [
  { label: "AI & SaaS", path: "/technologies/ai-saas" },
  { label: "Internet of Things (IoT)", path: "/technologies/iot" },
  { label: "5G & 6G Technologies", path: "/technologies/5g-6g" },
  { label: "Digital Chip Design", path: "/technologies/digital-chip-design" },
] as const;

export const homeSlides = [
  {
    number: "01",
    title: "Internet of Things (IoT)",
    highlight: "Product Development",
    copy: "Cogniot provides extensible and scalable IoT Products with business intelligence and insightful data analytics through connected devices and technologies.",
    image: media.heroIot,
    path: "/technologies/iot",
    action: "Read More",
  },
  {
    number: "02",
    title: "",
    highlight: "Information Technology Services",
    copy: "Cogniot provides advanced futuristic IT services such as Software and Web / Mobile Applications through creative design thinking process and acts as system integrator in IT products.",
    image: media.heroServices,
    path: "/services",
    action: "Read More",
  },
  {
    number: "03",
    title: "Application Specific",
    highlight: "Product Design and Testing",
    copy: "Cogniot provides innovative end-to-end technological solutions for complex Organizational / Societal / Governmental problems.",
    image: media.engineeringLab,
    path: "/services",
    action: "Read More",
  },
  {
    number: "04",
    title: "We’ve Accomplished",
    highlight: "10+ IT and IoT Projects",
    suffix: " this year!",
    copy: "Cogniot Technology is expertised in providing solutions to Educational Technology, Healthcare Technology, Agricultural Technology, Loan Automation and Finance Management.",
    image: media.heroProjects,
    path: "/portfolio",
    action: "Read More",
  },
] as const;

export const companyStats = [
  { value: 50, suffix: "+", label: "Government Clients" },
  { value: 40, suffix: "+", label: "Private Clients" },
  { value: 25000, suffix: "+", label: "Users" },
  { value: 25, suffix: "+", label: "Projects" },
] as const;

export const uniqueness = [
  {
    title: "Next Generation Design",
    text: "Cogniot is providing end-to-end technological solution through IoT product and Software development for challenging real-world problems.",
  },
  {
    title: "Core Strength",
    text: "Cogniot is having creative and smart expertise in product development, software development and system integration.",
  },
  {
    title: "Research and Development",
    text: "Cogniot is developing IoT technology through concerted research processes in wireless technology, sensor technology, artificial intelligence and data analytics.",
  },
  {
    title: "Purpose Driven Business",
    text: "Cogniot is understanding client’s requirement and offering the best customized solution with user friendly nature.",
  },
  {
    title: "Resource Planning Strategy",
    text: "Cogniot is delivering breakthrough IoT and software solution within the time frame and budget with perfection and high scalability.",
  },
  {
    title: "Client Support Services",
    text: "Cogniot is offering quality services to the clients up to entire satisfaction which turns their experience into fruitful business transformation.",
  },
] as const;

export const companyDomains = [
  "Healthcare technology",
  "Agricultural technology (agri-tech)",
  "Financial technology (fin-tech)",
  "Industrial technology",
  "Supply chain technology",
  "Educational technology",
] as const;

export const companySkills = [
  "HTML5",
  "CSS3",
  "JavaScript",
  "jQuery",
  "Bootstrap",
  "ASP.NET",
  "VB.NET",
  "JSON",
  "MySQL",
  "Flutter",
  "Kotlin",
  "Arduino",
  "Raspberry Pi",
  "LoRa",
  "RFID",
  "QR code",
] as const;

export const companyAddress =
  "I Floor, Tech Park, K.R. Innovation Centre, National Engineering College, Kovilpatti, Thoothukudi, Tamil Nadu – 628503";

export const companyVision =
  "Our vision is to become a leading Internet of Things and Services (IoTS) industry in India through innovation and customized engineering solution.";

export const missionPillars = [
  {
    title: "Product Development",
    text: "To develop hardware products with good internet connectivity and applications with data analytics capability for health care, agriculture, industry, logistics, fintech and academia.",
  },
  {
    title: "Customer Satisfaction",
    text: "To offer end-to-end high performance comprehensive IoTS solutions that would satisfy the customer expectations.",
  },
  {
    title: "Good Infrastructure",
    text: "To establish state-of-the-art infrastructure for feasible and cost effective solutions.",
  },
  {
    title: "Collaboration",
    text: "To collaborate with multi-disciplinary technocrats and industrialists.",
  },
] as const;

export const companyValues = [
  {
    title: "Innovation",
    text: "Innovation is the unique solution to handle the challenges. Cogniot always provides innovative end-to-end technical solutions to satisfy the needs of clients.",
  },
  {
    title: "Responsibility",
    text: "Responsibility lies in accepting challenges and providing solutions on time. Cogniot takes full responsibility to solve real-time problems faced by clients.",
  },
  {
    title: "Customer satisfaction",
    text: "Success of a project is keyed by satisfying clients. Cogniot improves customer experiences through on-time, personalized, optimized and secured product and service offerings.",
  },
  {
    title: "Professional ethics",
    text: "A code of ethics and business conduct builds reputation. Cogniot upholds business ethics and values towards clients and society, sustaining people, the economy and the environment.",
  },
  {
    title: "Transparency",
    text: "Business transparency comes from being open and straightforward in operations. Cogniot demonstrates a transparent culture in providing innovative solutions to clients.",
  },
  {
    title: "Integrity",
    text: "Integrity means being honest and trustworthy to clients. Cogniot promises quality outcomes, a long-term outlook and an innovative approach, with high confidentiality.",
  },
] as const;

export const leadershipPrinciples = companyValues.filter(
  (value) => value.title === "Innovation" || value.title === "Responsibility" || value.title === "Integrity",
);

export const recognitions = [
  {
    authority: "DPIIT · Government of India",
    title: "Recognised startup",
    text: "Cogniot Technology Private Limited is recognised as a startup by the Department for Promotion of Industry and Internal Trade (DPIIT), Government of India, in the Internet of Things industry.",
  },
  {
    authority: "Ministry of MSME · Government of India",
    title: "Udyam registered enterprise",
    text: "The Ministry of Micro, Small and Medium Enterprises, Government of India, has recognised Cogniot Technology Private Limited under the Udyam scheme.",
  },
  {
    authority: "Gyan Circle Ventures · IIIT Sri City",
    title: "First prize, entrepreneurship project contest",
    text: "Our team member won first prize in the Entrepreneurship Project Contest under the DST-sponsored Technology based Entrepreneurship Development Programme, 12 April – 22 May 2021.",
  },
  {
    authority: "MANAGE · Government of India",
    title: "Agripreneurship Orientation Programme",
    text: "Selected for the Agripreneurship Orientation Programme organised by MANAGE under RKVY-RAFTAAR — offered to 25 startups out of 450+ applications.",
  },
] as const;

export const milestones = [
  {
    when: "July 2020",
    title: "COGNIOT is incorporated",
    text: "Cogniot Technology Private Limited is incorporated as a private limited company in Kovilpatti, Tamil Nadu.",
  },
  {
    when: "April – May 2021",
    title: "First prize at IIIT Sri City",
    text: "First place in the Entrepreneurship Project Contest of the DST-sponsored Technology based Entrepreneurship Development Programme by Gyan Circle Ventures.",
  },
  {
    when: "June 2021",
    title: "DPIIT startup recognition",
    text: "Recognised as a startup in the Internet of Things industry by DPIIT, Government of India.",
  },
  {
    when: "June – August 2021",
    title: "MANAGE Agripreneurship programme",
    text: "Completed the two-month Agripreneurship Orientation Programme under RKVY-RAFTAAR, one of 25 startups selected from 450+ applications.",
  },
  {
    when: "Today",
    title: "10+ IT and IoT projects in a year",
    text: "Delivering solutions for educational, healthcare and agricultural technology, loan automation and finance management.",
  },
] as const;

export const clients = [
  {
    name: "Indian Railways",
    sector: "Government of India",
    category: "government",
    logo: railwaysImage,
  },
  {
    name: "National Institute of Ocean Technology",
    sector: "Ministry of Earth Sciences, Government of India",
    category: "government",
    logo: niotImage,
  },
  {
    name: "TABCEDCO",
    sector: "Government of Tamil Nadu",
    category: "government",
    logo: tabcedcoImage,
  },
  {
    name: "Kallar Reclamation Schools",
    sector: "Government of Tamil Nadu · Education",
    category: "government",
    logo: kallarImage,
  },
  {
    name: "Department of Backward Classes, Most Backward Classes & Minorities Welfare",
    sector: "Government of Tamil Nadu",
    category: "government",
    logo: welfareImage,
  },
  {
    name: "Egitim Ventures",
    sector: "Private sector",
    category: "private",
    logo: egitimImage,
  },
  {
    name: "Caprimec Technocrats",
    sector: "Private sector",
    category: "private",
    logo: caprimecImage,
  },
] as const;

export const testimonials = [
  {
    name: "T. Ganeshan",
    role: "CEO, Caprimec Technocrats Private Limited",
    quote:
      "We thank Cogniot Technology for the wonderful job in helping us develop our program. Everyone was professional, excellent and hard working. Thanks to them, we were able to achieve our goal on time, and we look forward to continue working with them in the future.",
  },
  {
    name: "Employees",
    role: "TABCEDCO",
    quote:
      "I have been involved in big projects for major corporations and the team at Cogniot Technology is the best that I have worked with. I would recommend them to anyone.",
  },
  {
    name: "Dr. G. Vinoth, BE, MS, Ph.D. (USA)",
    role: "Chief Executive Consultant",
    quote:
      "I wanted to take a moment to thank you for the services your team has provided. Your team has been a pleasure to work with, professional and timely. Job well done and I hope we can continue to grow together.",
  },
] as const;

export const ecosystem = [
  {
    title: "K.R. Innovation Centre, National Engineering College",
    text: "Our office is in the Tech Park at K.R. Innovation Centre, National Engineering College, Kovilpatti.",
  },
  {
    title: "Startup India · DPIIT",
    text: "Recognised startup in the Internet of Things industry.",
  },
  {
    title: "MANAGE · RKVY-RAFTAAR",
    text: "Agripreneurship Orientation Programme, National Institute of Agricultural Extension Management, Hyderabad.",
  },
  {
    title: "Gyan Circle Ventures · IIIT Sri City",
    text: "DST-sponsored Technology based Entrepreneurship Development Programme.",
  },
] as const;

export type TechnologyKey = "ai-saas" | "iot" | "5g-6g" | "digital-chip-design";

export interface TechnologyArea {
  key: TechnologyKey;
  path: (typeof technologyNavigation)[number]["path"];
  name: string;
  eyebrow: string;
  title: string;
  accent: string;
  description: string;
  overviewHeading: string;
  overview: readonly string[];
  image: string;
  imageAlt: string;
  capabilities: readonly { title: string; text: string }[];
  applications: readonly { title: string; text: string }[];
  toolkit: readonly string[];
  focusNote?: string;
}

export const technologyAreas: readonly TechnologyArea[] = [
  {
    key: "ai-saas",
    path: "/technologies/ai-saas",
    name: "AI & SaaS",
    eyebrow: "AI & SAAS",
    title: "Software that learns.",
    accent: "Platforms that scale.",
    description:
      "Data analytics, AI-assisted insight and cloud-delivered software for the workflows organisations depend on.",
    overviewHeading: "From records to decisions.",
    overview: [
      "Our research spans artificial intelligence and data analytics alongside wireless and sensor technology. We bring that work into software that organisations use every day — web and mobile applications that collect information, automate routine steps and surface what matters.",
      "Delivered as hosted, subscription-ready platforms, the same product can serve many offices, departments or customers while staying secure and easy to update.",
    ],
    image: media.aiSaas,
    imageAlt: "Illustrative engineer reviewing analytics dashboards.",
    capabilities: [
      { title: "Data analytics & dashboards", text: "Clear, role-aware views of operational data, trends and exceptions." },
      { title: "AI-assisted insight", text: "Models that classify, forecast and flag anomalies in business and sensor data." },
      { title: "Multi-tenant SaaS platforms", text: "Hosted products that serve many organisations from one secure, maintainable codebase." },
      { title: "Workflow automation", text: "Digitised approvals, processing and records that remove manual, repetitive work." },
      { title: "Integration & APIs", text: "Connecting new software with existing systems, devices and data sources." },
      { title: "Web & mobile apps", text: "Responsive web applications and Android / cross-platform mobile companions." },
    ],
    applications: [
      { title: "Loan automation", text: "Loan processing, disbursement workflows and account management." },
      { title: "Finance management", text: "Financial records, accounting workflows and organisational information." },
      { title: "Education technology", text: "Academic workflows and digital management systems for institutions." },
      { title: "Healthcare information", text: "Digital applications and information workflows for healthcare." },
    ],
    toolkit: ["ASP.NET", "VB.NET", "JavaScript", "jQuery", "JSON", "MySQL", "Flutter", "Kotlin"],
  },
  {
    key: "iot",
    path: "/technologies/iot",
    name: "Internet of Things (IoT)",
    eyebrow: "INTERNET OF THINGS",
    title: "Connected devices.",
    accent: "Insightful data.",
    description:
      "Extensible and scalable IoT products with business intelligence and insightful data analytics through connected devices and technologies.",
    overviewHeading: "Hardware, connectivity and software — designed together.",
    overview: [
      "IoT is where COGNIOT began. We develop hardware products with good internet connectivity and applications with data analytics capability for healthcare, agriculture, industry, logistics, fintech and academia.",
      "Each product brings sensors, embedded controllers, wireless links and dashboards into one considered design, then is tested against the way it will really be used.",
    ],
    image: media.heroIot,
    imageAlt: "Illustrative connected-device product development workspace.",
    capabilities: [
      { title: "Sensor integration", text: "Measuring temperature, UV, pH, TDS and other environmental values reliably." },
      { title: "Embedded controllers", text: "Device logic on Arduino and Raspberry Pi platforms." },
      { title: "Wireless connectivity", text: "LoRa, Wi-Fi and cellular links chosen for range, power and cost." },
      { title: "Identification", text: "RFID and QR code solutions for people, assets and access." },
      { title: "Cloud & analytics", text: "Dashboards, alerts and business intelligence on live device data." },
      { title: "Product design & testing", text: "Application-specific design and testing from prototype to deployment." },
    ],
    applications: [
      { title: "Aquaponics analytics", text: "Connected measurements of temperature, UV, pH and TDS." },
      { title: "Connected healthcare", text: "Connected-device concepts and digital health workflows." },
      { title: "Industrial monitoring", text: "Equipment information and process data from the floor." },
      { title: "Visitor management", text: "Identification and access workflows for campuses and offices." },
    ],
    toolkit: ["Arduino", "Raspberry Pi", "LoRa", "RFID", "QR code", "JSON", "MySQL", "Flutter"],
  },
  {
    key: "5g-6g",
    path: "/technologies/5g-6g",
    name: "5G & 6G Technologies",
    eyebrow: "5G / 6G CONNECTIVITY",
    title: "Next-generation networks.",
    accent: "Real-time possibilities.",
    description:
      "Designing connected products and applications ready for the speed, capacity and low latency of 5G — and the AI-native networks that follow.",
    overviewHeading: "Wireless research, applied to products.",
    overview: [
      "Wireless technology is one of COGNIOT’s core research areas. 5G brings higher bandwidth, lower latency and the ability to connect far more devices per area — exactly what large sensor networks and real-time applications need.",
      "We help shape device, edge and cloud architecture so that products take advantage of these networks today and are ready for the sensing-aware, AI-native capabilities expected in 6G.",
    ],
    image: media.wireless,
    imageAlt: "Illustrative wireless communications tower over a city.",
    capabilities: [
      { title: "5G-ready IoT devices", text: "Selecting modules and designing devices for cellular IoT connectivity." },
      { title: "Edge computing", text: "Processing data close to the device for faster, lower-latency decisions." },
      { title: "Massive sensor networks", text: "Architectures that scale from a few devices to thousands per site." },
      { title: "Real-time applications", text: "Monitoring and control software built for live, high-frequency data." },
      { title: "Network-aware security", text: "Secure device identity and encrypted device-to-cloud communication." },
      { title: "6G research watch", text: "Following integrated sensing and AI-native networking for future products." },
    ],
    applications: [
      { title: "Smart agriculture", text: "Wide-area field sensing with dependable connectivity." },
      { title: "Remote healthcare", text: "Responsive links for connected monitoring devices." },
      { title: "Industrial IoT", text: "Low-latency equipment monitoring and process data." },
      { title: "Logistics tracking", text: "Connected tracking for assets on the move." },
    ],
    toolkit: ["5G NR", "Cellular IoT", "Edge computing", "LoRa", "Wi-Fi", "MQTT / JSON"],
    focusNote: "5G / 6G is a developing focus area. Contact us to discuss your connectivity requirements.",
  },
  {
    key: "digital-chip-design",
    path: "/technologies/digital-chip-design",
    name: "Digital Chip Design",
    eyebrow: "DIGITAL CHIP DESIGN",
    title: "Application-specific silicon.",
    accent: "Engineered with care.",
    description:
      "Digital logic design, FPGA prototyping and verification for products that need dedicated, efficient hardware.",
    overviewHeading: "When off-the-shelf hardware is not enough.",
    overview: [
      "Some products need logic that is faster, smaller or more power-efficient than a general-purpose controller can offer. Digital chip design turns that requirement into dedicated hardware.",
      "Building on our application-specific product design and testing experience, we describe digital logic, prove it on FPGA prototypes and verify it carefully before it moves towards production.",
    ],
    image: media.digitalChip,
    imageAlt: "Illustrative semiconductor wafer and digital chip design.",
    capabilities: [
      { title: "Specification & architecture", text: "Turning product requirements into a clear hardware architecture." },
      { title: "RTL design", text: "Digital logic described in Verilog / VHDL for synthesis." },
      { title: "Functional verification", text: "Simulation and test benches that prove behaviour before hardware." },
      { title: "FPGA prototyping", text: "Running designs on real hardware early to de-risk development." },
      { title: "Hardware–software integration", text: "Firmware, drivers and applications that work with the custom logic." },
      { title: "Testing & validation", text: "Bench testing against the intended application and environment." },
    ],
    applications: [
      { title: "Sensor interfaces", text: "Dedicated logic for fast, precise signal acquisition." },
      { title: "Low-power IoT nodes", text: "Efficient hardware for battery-powered devices." },
      { title: "Signal processing", text: "Hardware acceleration for filtering and data processing." },
      { title: "Secure identification", text: "Hardware support for authentication and encryption." },
    ],
    toolkit: ["Verilog", "VHDL", "FPGA", "Simulation", "Embedded C", "Arduino / Raspberry Pi"],
    focusNote: "Digital chip design is a developing focus area. Contact us to discuss your hardware requirements.",
  },
] as const;

export const homepageProjects = [
  {
    category: "Public services",
    title: "TABCEDCO loan automation and management",
    text: "A web application concept for loan processing, disbursement workflows, and account management.",
    image: media.heroProjects,
    alt: "Illustrative digital services image; not a project screenshot.",
  },
  {
    category: "Agriculture and IoT",
    title: "Aquaponics analytics",
    text: "Connected measurements and analytics for aquaponics environments, including temperature, UV, pH, and TDS.",
    image: media.aquaponics,
    alt: "Illustrative aquaponics greenhouse.",
  },
  {
    category: "Healthcare technology",
    title: "COVAMAS",
    text: "A healthcare technology initiative represented in the supplied project portfolio.",
    image: media.healthcare,
    alt: "Illustrative connected healthcare image; not a project screenshot.",
  },
] as const;

export const portfolioProjects = [
  ...homepageProjects,
  {
    category: "Financial technology",
    title: "COFIMASS",
    text: "A finance and information-management solution represented in the supplied project portfolio.",
    image: media.engineeringLab,
    alt: "Illustrative engineering lab; not a project screenshot.",
  },
] as const;

export const serviceCategories = [
  { title: "IoT product development", text: "Connected products that bring sensors, devices, and useful data together." },
  { title: "Software development", text: "Purpose-built software for the workflows organisations depend on." },
  { title: "Web application development", text: "Responsive web applications for customer, staff, and operational experiences." },
  { title: "Mobile application development", text: "Mobile experiences that bring useful services closer to people." },
  { title: "Hardware product development", text: "Application-specific hardware concepts built around connectivity and sensing." },
  { title: "Product design and testing", text: "A considered path from product requirements through design and testing." },
  { title: "AI and data analytics", text: "Turn connected and operational data into clearer decisions." },
  { title: "System integration", text: "Connect devices, applications, and workflows into a coherent solution." },
  { title: "Technology consulting", text: "Practical technology guidance shaped around the problem and its users." },
] as const;

export const contactServiceOptions = [
  "IoT product development",
  "Software development",
  "Web application development",
  "Mobile application development",
  "Hardware product development",
  "Product design and testing",
  "AI and data analytics",
  "System integration",
  "Technology consulting",
  "Other",
] as const;