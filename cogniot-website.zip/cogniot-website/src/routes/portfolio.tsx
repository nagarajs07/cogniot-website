import { createFileRoute } from "@tanstack/react-router";

import { PortfolioPage } from "@/components/site-pages";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/portfolio")({
  head: () => ({
    meta: pageMeta(
      "Portfolio | COGNIOT Technology",
      "Explore project areas represented in COGNIOT’s source materials, including loan automation, aquaponics analytics, healthcare technology, and finance management.",
    ),
  }),
  component: PortfolioPage,
});