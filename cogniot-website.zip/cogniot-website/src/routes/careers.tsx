import { createFileRoute } from "@tanstack/react-router";

import { CareersPage } from "@/components/site-pages";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/careers")({
  head: () => ({
    meta: pageMeta(
      "Careers | COGNIOT Technology",
      "Explore internship and job opportunities at COGNIOT and submit your profile for current or future roles.",
    ),
  }),
  component: CareersPage,
});