import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight, Cpu, HeartPulse, Layers3, Lightbulb, Radio, ShieldCheck, Sparkles, Wifi } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  CAROUSEL_INTERVAL_MS,
  companyDomains,
  companyStats,
  homeSlides,
  homepageProjects,
  media,
  uniqueness,
} from "@/lib/site-content";
import { ContactBand, CountUp, Reveal, SectionHeading } from "@/components/site-shell";

const highlights = [
  { icon: Lightbulb, label: "PRODUCTS" },
  { icon: Layers3, label: "SOFTWARE" },
  { icon: Wifi, label: "CONNECTED SYSTEMS" },
];

function HeroCarousel() {
  const [current, setCurrent] = useState(0);
  const [focused, setFocused] = useState(false);

  useEffect(() => {
    if (focused || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const timer = window.setInterval(() => {
      setCurrent((slide) => (slide + 1) % homeSlides.length);
    }, CAROUSEL_INTERVAL_MS);
    return () => window.clearInterval(timer);
  }, [current, focused]);

  return (
    <section
      className="home-hero hero-carousel"
      aria-roledescription="carousel"
      aria-label="COGNIOT highlights"
      onFocusCapture={() => setFocused(true)}
      onBlurCapture={(event) => {
        if (!(event.relatedTarget instanceof Node && event.currentTarget.contains(event.relatedTarget))) {
          setFocused(false);
        }
      }}
    >
      <div className="home-hero-media" aria-hidden="true">
        {homeSlides.map((slide, index) => (
          <img
            key={slide.number}
            className={`hero-slide-bg${index === current ? " is-active" : ""}`}
            src={slide.image}
            alt=""
            decoding="async"
            fetchPriority={index === 0 ? "high" : "auto"}
          />
        ))}
        <div className="home-hero-shade" />
      </div>

      <div className="container home-hero-content">
        <div className="hero-slides" aria-live="off">
          {homeSlides.map((slide, index) => {
            const active = index === current;
            const Heading = active ? "h1" : "h2";
            return (
              <div
                key={slide.number}
                className={`hero-slide${active ? " is-active" : ""}`}
                role="group"
                aria-roledescription="slide"
                aria-label={`${slide.number} of 04`}
                aria-hidden={!active}
              >
                <div className="hero-slide-number" aria-hidden="true">
                  <span>{slide.number}</span><span className="hero-slide-total">/ 04</span>
                </div>
                <Heading className="hero-slide-title">
                  {slide.title}{slide.title && slide.highlight ? " " : ""}
                  {slide.highlight ? <span className="hero-highlight">{slide.highlight}</span> : null}
                  {"suffix" in slide ? slide.suffix : null}
                </Heading>
                <p className="hero-slide-copy">{slide.copy}</p>
                <Button asChild className="hero-read-more">
                  <Link to={slide.path} tabIndex={active ? 0 : -1}>
                    {slide.action} <ArrowUpRight aria-hidden="true" />
                  </Link>
                </Button>
              </div>
            );
          })}
        </div>

        <div className="hero-dots" role="group" aria-label="Choose slide">
          {homeSlides.map((slide, index) => (
            <Button
              key={slide.number}
              type="button"
              variant="ghost"
              className={`hero-dot${current === index ? " is-active" : ""}`}
              aria-label={`Show slide ${slide.number}`}
              aria-current={current === index ? "true" : undefined}
              onClick={() => setCurrent(index)}
            >
              <span className="hero-dot-number">{slide.number}</span>
              <span className="hero-dot-bar" aria-hidden="true"><span /></span>
            </Button>
          ))}
        </div>
      </div>

      <div className="container hero-bottom-line" aria-label="COGNIOT areas">
        {highlights.map(({ icon: Icon, label }, index) => (
          <span className="hero-bottom-item" key={label}>
            <Icon aria-hidden="true" />{label}{index < highlights.length - 1 ? <i aria-hidden="true" /> : null}
          </span>
        ))}
      </div>
    </section>
  );
}

export function HomePage() {
  return (
    <>
      <HeroCarousel />

      <section className="stats-section" aria-label="COGNIOT in numbers">
        <div className="container stats-grid">
          {companyStats.map((stat) => (
            <CountUp key={stat.label} value={stat.value} suffix={stat.suffix} label={stat.label} />
          ))}
        </div>
      </section>

      <section className="content-section uniqueness-section">
        <div className="container">
          <SectionHeading eyebrow="WHY COGNIOT" title="Our Uniqueness" />
          <div className="uniqueness-grid">
            {uniqueness.map((item, index) => (
              <Reveal key={item.title} className="feature-card" delay={index % 3 === 1 ? "1" : index % 3 === 2 ? "2" : undefined}>
                <div className="feature-card-top">
                  <span className="feature-icon">
                    {index === 0 ? <Sparkles aria-hidden="true" /> : null}
                    {index === 1 ? <Layers3 aria-hidden="true" /> : null}
                    {index === 2 ? <Cpu aria-hidden="true" /> : null}
                    {index === 3 ? <Lightbulb aria-hidden="true" /> : null}
                    {index === 4 ? <ShieldCheck aria-hidden="true" /> : null}
                    {index === 5 ? <HeartPulse aria-hidden="true" /> : null}
                  </span>
                  <span className="feature-index">{String(index + 1).padStart(2, "0")}</span>
                </div>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="content-section story-preview-section">
        <div className="container story-preview">
          <Reveal className="story-preview-copy">
            <p className="eyebrow">WHO WE ARE</p>
            <h2>Technology should solve <span>the right problems.</span></h2>
            <p>COGNIOT is a technology and product development company focused on connected devices, software, web applications, and practical digital transformation.</p>
            <Button asChild variant="outline" className="text-link-button">
              <Link to="/about/our-story">More about us <ArrowRight aria-hidden="true" /></Link>
            </Button>
          </Reveal>
          <Reveal className="story-preview-image" delay="1">
            <img src={media.engineeringLab} alt="Illustrative engineering lab." loading="lazy" />
            <span className="image-caption">Ideas into intelligent impact</span>
          </Reveal>
        </div>
      </section>

      <section className="content-section domains-section">
        <div className="container domains-layout">
          <SectionHeading
            eyebrow="WHERE WE WORK"
            title="Different sectors. Connected possibilities."
            summary="We adapt technology to the context, constraints, and opportunities of agriculture, healthcare, finance, industry, and public services."
          />
          <div className="domain-list">
            {companyDomains.map((domain, index) => (
              <Reveal key={domain} className="domain-item" delay={index % 3 === 1 ? "1" : index % 3 === 2 ? "2" : undefined}>
                <span>{String(index + 1).padStart(2, "0")}</span>
                <strong>{domain}</strong>
                <ArrowUpRight aria-hidden="true" />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="content-section project-preview-section">
        <div className="container">
          <div className="section-heading-row">
            <SectionHeading
              eyebrow="SELECTED WORK"
              title="Ideas made tangible."
              summary="A snapshot of the project areas represented in the supplied COGNIOT portfolio."
            />
            <Button asChild variant="outline" className="text-link-button">
              <Link to="/portfolio">Explore the portfolio <ArrowRight aria-hidden="true" /></Link>
            </Button>
          </div>
          <div className="project-grid">
            {homepageProjects.map((project, index) => (
              <Reveal key={project.title} className="project-card" delay={index === 1 ? "1" : index === 2 ? "2" : undefined}>
                <div className="project-image"><img src={project.image} alt={project.alt} loading="lazy" /></div>
                <div className="project-body">
                  <p className="project-category"><span>{String(index + 1).padStart(2, "0")}</span>{project.category}</p>
                  <h3>{project.title}</h3>
                  <p>{project.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
          <p className="source-note">The photographs are illustrative, not project screenshots. Project descriptions follow the supplied portfolio material.</p>
        </div>
      </section>

      <ContactBand />
    </>
  );
}