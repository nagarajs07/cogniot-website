import { createFileRoute } from "@tanstack/react-router";

import { RecognitionsPage } from "@/components/site-pages";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/about/recognitions-milestones")({
  head: () => ({
    meta: pageMeta(
      "Recognitions & Milestones | COGNIOT Technology",
      "COGNIOT’s DPIIT recognition, Udyam registration, IIIT Sri City achievement, MANAGE programme, and documented milestones.",
    ),
  }),
  component: RecognitionsPage,
});