import { createFileRoute } from "@tanstack/react-router";

import { HomePage } from "@/components/home-page";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: pageMeta(
      "COGNIOT Technology | Ideas into intelligent impact",
      "Connected products, purposeful software, and practical engineering from COGNIOT Technology Private Limited.",
    ),
  }),
  component: HomePage,
});