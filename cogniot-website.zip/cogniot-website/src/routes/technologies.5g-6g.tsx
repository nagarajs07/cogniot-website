import { createFileRoute } from "@tanstack/react-router";

import { TechnologyDetailPage } from "@/components/site-pages";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/technologies/5g-6g")({
  head: () => ({
    meta: pageMeta(
      "5G & 6G Technologies | COGNIOT Technology",
      "Industry context and COGNIOT’s developing focus on next-generation wireless connectivity for connected products and applications.",
    ),
  }),
  component: FiveGSixGPage,
});

function FiveGSixGPage() {
  return <TechnologyDetailPage technologyKey="5g-6g" />;
}