import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight, Award, Building2, Check, Cpu, Eye, Handshake, HeartPulse, Lightbulb, MapPin, Radio, ShieldCheck, UserRound, Wifi } from "lucide-react";

import { Button } from "@/components/ui/button";
import { CareerApplicationForm, ContactForm } from "@/components/lead-capture-forms";
import { ContactBand, PageHero, Reveal, SectionHeading, Timeline } from "@/components/site-shell";
import {
  clients,
  companyAddress,
  companyDomains,
  companySkills,
  companyStats,
  companyValues,
  companyVision,
  ecosystem,
  leadershipPrinciples,
  media,
  milestones,
  missionPillars,
  portfolioProjects,
  recognitions,
  serviceCategories,
  technologyAreas,
  testimonials,
  type TechnologyKey,
} from "@/lib/site-content";

export function OurStoryPage() {
  return (
    <>
      <PageHero
        eyebrow="WHO WE ARE"
        title="A fast-growing startup with"
        highlight="experienced technocrats."
        summary="COGNIOT Technology Private Limited builds customised technology solutions through Internet of Things products and software services."
        image={media.heroIot}
        breadcrumbs={[{ label: "About Us", to: "/about/our-story" }, { label: "Our Story" }]}
      />
      <section className="content-section story-detail-section">
        <div className="container story-detail-layout">
          <Reveal className="story-detail-copy">
            <SectionHeading eyebrow="OUR STORY" title="Technology with a clear purpose." />
            <p>Cogniot Technology Private Limited, located in the southern part of Tamil Nadu, is an innovative business-to-business company that provides customised technological solutions to its customers through Internet of Things products and software services.</p>
            <p>Cogniot is one of the fast-growing startup companies in Tamil Nadu with experienced technocrats. We strive to build strong, long-term relationships with customers through quality services and by satisfying their expectations.</p>
            <p>We deliver high-impact solutions to domains such as healthcare, agricultural, financial, industrial and supply chain technology — with value-added products and high-quality services. We also offer consultation and support services.</p>
          </Reveal>
          <Reveal className="story-facts" delay="1">
            <div className="story-facts-top">
              <img src={media.logo} alt="COGNIOT Technology" />
              <span>At a glance</span>
            </div>
            <dl>
              <div><dt>Incorporated</dt><dd>July 2020</dd></div>
              <div><dt>Headquarters</dt><dd>Kovilpatti, Thoothukudi, Tamil Nadu</dd></div>
              <div><dt>Business model</dt><dd>Business-to-business</dd></div>
              <div><dt>Core offering</dt><dd>IoT products &amp; software services</dd></div>
              <div><dt>Recognition</dt><dd>DPIIT-recognised startup · Udyam registered</dd></div>
            </dl>
          </Reveal>
        </div>
      </section>

      <section className="content-section soft-section">
        <div className="container">
          <SectionHeading eyebrow="THE JOURNEY" title="Three chapters, one direction." />
          <Timeline>
            {[
              { when: "01 · 2020", title: "The beginning", text: "COGNIOT is incorporated and sets up in the Tech Park at K.R. Innovation Centre, National Engineering College, Kovilpatti — with a focus on IoT products and software." },
              { when: "02 · 2021", title: "Recognition", text: "Recognised as a startup by DPIIT, registered under MSME Udyam, first prize at IIIT Sri City and selected for the MANAGE Agripreneurship programme." },
              { when: "03 · TODAY", title: "Growing impact", text: "10+ IT and IoT projects in a year for government and private clients across education, healthcare, agriculture, loan automation and finance." },
            ].map((step) => (
              <li className="timeline-item" key={step.when}>
                <span className="timeline-dot" aria-hidden="true"><Check /></span>
                <article className="timeline-card">
                  <span className="timeline-when">{step.when}</span>
                  <h3>{step.title}</h3>
                  <p>{step.text}</p>
                </article>
              </li>
            ))}
          </Timeline>
          <Button asChild variant="outline" className="text-link-button story-recognition-link">
            <Link to="/about/recognitions-milestones">See all recognitions &amp; milestones <ArrowRight aria-hidden="true" /></Link>
          </Button>
        </div>
      </section>

      <section className="content-section">
        <div className="container domains-layout">
          <SectionHeading
            eyebrow="WHERE WE WORK"
            title="Domains we serve."
            summary="Solutions with value-added products and high-quality services, plus consultation and support."
          />
          <ul className="chip-list chip-list-large">
            {companyDomains.map((domain) => <li key={domain}>{domain}</li>)}
          </ul>
        </div>
      </section>

      <section className="content-section soft-section">
        <div className="container skills-layout">
          <SectionHeading
            eyebrow="OUR SKILLS"
            title="Web, mobile and IoT applications."
            summary="Knowledge and reputation are defined by the technology and skill set a company applies to give clients the right technical solution."
          />
          <ul className="chip-list">
            {companySkills.map((skill) => <li key={skill}>{skill}</li>)}
          </ul>
        </div>
      </section>

      <section className="content-section">
        <div className="container location-band">
          <span className="location-icon"><MapPin aria-hidden="true" /></span>
          <div>
            <p className="eyebrow">FIND US</p>
            <h2>K.R. Innovation Centre, National Engineering College</h2>
            <p>{companyAddress}</p>
          </div>
          <Button asChild variant="outline"><Link to="/contact">Contact us <ArrowUpRight aria-hidden="true" /></Link></Button>
        </div>
      </section>
      <ContactBand />
    </>
  );
}

export function VisionMissionPage() {
  return (
    <>
      <PageHero
        eyebrow="VISION & MISSION"
        title="Engineering with"
        highlight="purpose."
        summary="A clear vision, four mission commitments, and values that guide the way COGNIOT works."
        image={media.engineeringLab}
        breadcrumbs={[{ label: "About Us", to: "/about/our-story" }, { label: "Vision & Mission" }]}
      />
      <section className="content-section vision-section">
        <div className="container">
          <Reveal className="vision-statement">
            <span className="vision-icon"><Eye aria-hidden="true" /></span>
            <p className="eyebrow">OUR VISION</p>
            <blockquote>{companyVision}</blockquote>
          </Reveal>
        </div>
      </section>
      <section className="content-section soft-section">
        <div className="container">
          <SectionHeading eyebrow="OUR MISSION" title="Four commitments that guide the work." />
          <div className="card-grid mission-grid">
            {missionPillars.map((pillar, index) => (
              <Reveal key={pillar.title} className="content-card mission-card" delay={index % 3 === 1 ? "1" : index % 3 === 2 ? "2" : undefined}>
                <span className="card-index">{String(index + 1).padStart(2, "0")}</span>
                <span className="card-icon">
                  {index === 0 ? <Cpu aria-hidden="true" /> : null}
                  {index === 1 ? <HeartPulse aria-hidden="true" /> : null}
                  {index === 2 ? <Building2 aria-hidden="true" /> : null}
                  {index === 3 ? <Handshake aria-hidden="true" /> : null}
                </span>
                <h3>{pillar.title}</h3>
                <p>{pillar.text}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <section className="content-section">
        <div className="container">
          <SectionHeading eyebrow="KEY VALUES" title="What we stand for." />
          <div className="card-grid values-grid">
            {companyValues.map((value, index) => (
              <Reveal key={value.title} className="content-card value-card" delay={index % 3 === 1 ? "1" : index % 3 === 2 ? "2" : undefined}>
                <span className="card-icon">
                  {index === 0 ? <Lightbulb aria-hidden="true" /> : null}
                  {index === 1 ? <ShieldCheck aria-hidden="true" /> : null}
                  {index === 2 ? <HeartPulse aria-hidden="true" /> : null}
                  {index === 3 ? <Check aria-hidden="true" /> : null}
                  {index === 4 ? <Eye aria-hidden="true" /> : null}
                  {index === 5 ? <ShieldCheck aria-hidden="true" /> : null}
                </span>
                <h3>{value.title}</h3>
                <p>{value.text}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <ContactBand />
    </>
  );
}

export function LeadershipTeamPage() {
  return (
    <>
      <PageHero
        eyebrow="OUR LEADERS"
        title="The team behind"
        highlight="the work."
        summary="Multi-disciplinary expertise across IoT product development, software engineering and system integration."
        image={media.heroServices}
        breadcrumbs={[{ label: "About Us", to: "/about/our-story" }, { label: "Leadership & Team" }]}
      />
      <section className="content-section">
        <div className="container">
          <div className="section-heading-row">
            <SectionHeading
              eyebrow="LEADERSHIP & TEAM"
              title="People, ideas, and engineering."
              summary="Verified leadership names, designations, biographies and photographs were not supplied in the original website materials."
            />
            <p className="section-aside-note">Profiles will appear here once COGNIOT confirms the details.</p>
          </div>
          <div className="leader-grid">
            {[1, 2, 3, 4].map((number, index) => (
              <Reveal key={number} className="leader-card" delay={index === 1 ? "1" : index === 2 ? "2" : undefined}>
                <div className="leader-photo">
                  <span className="leader-index">{String(number).padStart(2, "0")}</span>
                  <span className="leader-silhouette"><UserRound aria-hidden="true" /></span>
                  <span className="leader-photo-hint">Profile awaiting details</span>
                </div>
                <div className="leader-body">
                  <p className="leader-pending">Details to be confirmed</p>
                  <h3>Leadership profile</h3>
                  <p className="leader-role">Official designation</p>
                  <p className="leader-bio">A short professional biography will appear here once it has been confirmed by COGNIOT.</p>
                  <div className="leader-expertise">
                    <span>AREA OF EXPERTISE</span>
                    <ul><li>Expertise to be confirmed</li></ul>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <section className="content-section soft-section">
        <div className="container">
          <SectionHeading eyebrow="HOW WE LEAD" title="Principles our leaders share." />
          <div className="card-grid values-grid leadership-values">
            {leadershipPrinciples.map((value, index) => (
              <Reveal key={value.title} className="content-card value-card" delay={index === 1 ? "1" : index === 2 ? "2" : undefined}>
                <span className="card-index">{String(index + 1).padStart(2, "0")}</span>
                <h3>{value.title}</h3>
                <p>{value.text}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <ContactBand />
    </>
  );
}

export function RecognitionsPage() {
  return (
    <>
      <PageHero
        eyebrow="RECOGNITIONS & ACHIEVEMENTS"
        title="Trusted by institutions"
        highlight="that set the bar."
        summary="Official recognitions, programme selections, and milestones from COGNIOT’s documented journey."
        image={media.heroProjects}
        breadcrumbs={[{ label: "About Us", to: "/about/our-story" }, { label: "Recognitions & Milestones" }]}
      />
      <section className="stats-section recognition-stats" aria-label="COGNIOT in numbers">
        <div className="container stats-grid">
          {companyStats.map((stat) => <div className="stat-card" key={stat.label}><span className="stat-value">{new Intl.NumberFormat("en-US").format(stat.value)}{stat.suffix}</span><span className="stat-label">{stat.label}</span></div>)}
        </div>
      </section>
      <section className="content-section">
        <div className="container">
          <SectionHeading eyebrow="RECOGNITIONS & ACHIEVEMENTS" title="Recognised for the work." />
          <div className="recognition-layout">
            <div className="card-grid recognition-grid">
              {recognitions.map((item, index) => (
                <Reveal className="content-card recognition-card" key={item.title} delay={index % 2 === 1 ? "1" : undefined}>
                  <span className="card-icon">
                    {index === 0 ? <Award aria-hidden="true" /> : null}
                    {index === 1 ? <Building2 aria-hidden="true" /> : null}
                    {index === 2 ? <Check aria-hidden="true" /> : null}
                    {index === 3 ? <Lightbulb aria-hidden="true" /> : null}
                  </span>
                  <span className="recognition-authority">{item.authority}</span>
                  <h3>{item.title}</h3>
                  <p>{item.text}</p>
                </Reveal>
              ))}
            </div>
            <Reveal className="certificate-figure" delay="1">
              <img src={media.dpiitCertificate} alt="DPIIT Certificate of Recognition supplied with the COGNIOT website." loading="lazy" />
              <p>DPIIT Certificate of Recognition · Startup India</p>
            </Reveal>
          </div>
        </div>
      </section>
      <section className="content-section soft-section">
        <div className="container">
          <SectionHeading eyebrow="MILESTONES" title="The journey so far." />
          <Timeline>
            {milestones.map((item) => (
              <li className="timeline-item" key={item.title}>
                <span className="timeline-dot" aria-hidden="true"><Award /></span>
                <article className="timeline-card">
                  <span className="timeline-when">{item.when}</span>
                  <h3>{item.title}</h3>
                  <p>{item.text}</p>
                </article>
              </li>
            ))}
          </Timeline>
        </div>
      </section>
      <ContactBand />
    </>
  );
}

export function ClientsPartnersPage() {
  const [filter, setFilter] = useState<"all" | "government" | "private">("all");
  const filters = [
    { label: "All", value: "all" },
    { label: "Government", value: "government" },
    { label: "Private", value: "private" },
  ] as const;

  return (
    <>
      <PageHero
        eyebrow="OUR CLIENTS & PARTNERS"
        title="Organisations"
        highlight="we serve."
        summary="Client logos, testimonials, and ecosystem details represented in the supplied COGNIOT website material."
        image={media.heroProjects}
        breadcrumbs={[{ label: "About Us", to: "/about/our-story" }, { label: "Our Clients & Partners" }]}
      />
      <section className="logo-marquee-section" aria-label="Selected client organisations">
        <div className="logo-marquee-track">
          {[...clients, ...clients].map((client, index) => (
            <div className="logo-marquee-item" key={`${client.name}-${index}`}>
              <img src={client.logo} alt={index < clients.length ? client.name : ""} aria-hidden={index >= clients.length} loading="lazy" />
            </div>
          ))}
        </div>
      </section>
      <section className="content-section">
        <div className="container">
          <div className="section-heading-row clients-heading-row">
            <SectionHeading eyebrow="OUR CLIENTS" title="Organisations served." />
            <div className="client-filter" role="group" aria-label="Filter clients by type">
              {filters.map((option) => (
                <Button
                  key={option.value}
                  type="button"
                  variant={filter === option.value ? "default" : "ghost"}
                  size="sm"
                  aria-pressed={filter === option.value}
                  onClick={() => setFilter(option.value)}
                >
                  {option.label}
                </Button>
              ))}
            </div>
          </div>
          <ul className="client-grid">
            {clients.map((client) => (
              <li key={client.name} className="client-card" hidden={filter !== "all" && client.category !== filter}>
                <div className="client-logo"><img src={client.logo} alt={client.name} loading="lazy" /></div>
                <h3>{client.name}</h3>
                <span className="client-sector">{client.sector}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>
      <section className="content-section soft-section">
        <div className="container">
          <SectionHeading eyebrow="TESTIMONIALS" title="In their words." />
          <div className="card-grid testimonial-grid">
            {testimonials.map((item, index) => (
              <Reveal key={item.name} className="testimonial-card" delay={index === 1 ? "1" : index === 2 ? "2" : undefined}>
                <span className="testimonial-mark" aria-hidden="true">“</span>
                <blockquote><p>{item.quote}</p></blockquote>
                <figcaption><strong>{item.name}</strong><span>{item.role}</span></figcaption>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <section className="content-section">
        <div className="container">
          <SectionHeading
            eyebrow="ECOSYSTEM & PROGRAMMES"
            title="The network that supports our growth."
            summary="Institutions and programmes connected to COGNIOT’s journey as a startup."
          />
          <div className="card-grid ecosystem-grid">
            {ecosystem.map((item, index) => (
              <Reveal key={item.title} className="content-card ecosystem-card" delay={index % 3 === 1 ? "1" : index % 3 === 2 ? "2" : undefined}>
                <span className="card-icon">
                  {index === 0 ? <MapPin aria-hidden="true" /> : null}
                  {index === 1 ? <Award aria-hidden="true" /> : null}
                  {index === 2 ? <Lightbulb aria-hidden="true" /> : null}
                  {index === 3 ? <Handshake aria-hidden="true" /> : null}
                </span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <ContactBand />
    </>
  );
}

export function TechnologiesOverviewPage() {
  const stack = [
    { layer: "01 · SILICON", title: "Digital chip design", icon: Cpu, path: "/technologies/digital-chip-design" },
    { layer: "02 · DEVICE", title: "Internet of Things", icon: Radio, path: "/technologies/iot" },
    { layer: "03 · NETWORK", title: "5G / 6G connectivity", icon: Wifi, path: "/technologies/5g-6g" },
    { layer: "04 · PLATFORM", title: "AI & SaaS", icon: Lightbulb, path: "/technologies/ai-saas" },
  ] as const;

  return (
    <>
      <PageHero
        eyebrow="OUR TECHNOLOGY AREAS"
        title="Four disciplines,"
        highlight="designed to work together."
        summary="Hardware senses and processes, devices connect, networks carry the data, and software turns it into decisions."
        image={media.engineeringLab}
        breadcrumbs={[{ label: "Technologies" }]}
      />
      <section className="content-section">
        <div className="container">
          <SectionHeading eyebrow="TECHNOLOGY AREAS" title="Explore the disciplines." />
          <div className="tech-card-grid">
            {technologyAreas.map((area, index) => (
              <Reveal key={area.key} className="tech-card" delay={index === 1 ? "1" : index === 2 ? "2" : undefined}>
                <Link to={area.path} className="tech-card-image">
                  <img src={area.image} alt={area.imageAlt} loading="lazy" />
                  <span className="tech-card-count">{String(index + 1).padStart(2, "0")}</span>
                </Link>
                <div className="tech-card-body">
                  <span className="tech-card-icon">
                    {index === 0 ? <Lightbulb aria-hidden="true" /> : null}
                    {index === 1 ? <Radio aria-hidden="true" /> : null}
                    {index === 2 ? <Wifi aria-hidden="true" /> : null}
                    {index === 3 ? <Cpu aria-hidden="true" /> : null}
                  </span>
                  <h3>{area.name}</h3>
                  <p>{area.description}</p>
                  <Link to={area.path} className="tech-card-link">Explore {area.name} <ArrowUpRight aria-hidden="true" /></Link>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <section className="content-section tech-stack-section">
        <div className="container">
          <SectionHeading
            eyebrow="HOW IT CONNECTS"
            title="Every layer of a connected product."
            summary="Dedicated hardware senses and processes, devices connect, networks carry the data, and software turns it into decisions."
          />
          <ol className="tech-stack">
            {stack.map(({ layer, title, icon: Icon, path }) => (
              <li key={layer}>
                <span className="tech-stack-icon"><Icon aria-hidden="true" /></span>
                <span className="tech-stack-layer">{layer}</span>
                <strong>{title}</strong>
                <Link to={path}>Learn more <ArrowUpRight aria-hidden="true" /></Link>
              </li>
            ))}
          </ol>
        </div>
      </section>
      <section className="content-section">
        <div className="container">
          <SectionHeading eyebrow="TOOLS WE USE" title="Our everyday toolkit." />
          <ul className="chip-list">{companySkills.map((skill) => <li key={skill}>{skill}</li>)}</ul>
        </div>
      </section>
      <ContactBand />
    </>
  );
}

export function TechnologyDetailPage({ technologyKey }: { technologyKey: TechnologyKey }) {
  const area = technologyAreas.find((item) => item.key === technologyKey);
  if (!area) return null;

  return (
    <>
      <PageHero
        eyebrow={area.eyebrow}
        title={area.title}
        highlight={area.accent}
        summary={area.description}
        image={area.image}
        breadcrumbs={[{ label: "Technologies", to: "/technologies" }, { label: area.name }]}
      />
      <section className="content-section">
        <div className="container tech-overview">
          <Reveal className="tech-overview-copy">
            <SectionHeading eyebrow={area.eyebrow} title={area.overviewHeading} />
            {area.overview.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
            {area.focusNote ? <p className="focus-note"><ShieldCheck aria-hidden="true" />{area.focusNote}</p> : null}
          </Reveal>
          <Reveal className="tech-overview-figure" delay="1">
            <img src={area.image} alt={area.imageAlt} loading="lazy" />
            <span className="tech-figure-icon" aria-hidden="true">
              {technologyKey === "iot" ? <Radio /> : null}
              {technologyKey === "ai-saas" ? <Lightbulb /> : null}
              {technologyKey === "5g-6g" ? <Wifi /> : null}
              {technologyKey === "digital-chip-design" ? <Cpu /> : null}
            </span>
          </Reveal>
        </div>
      </section>
      <section className="content-section soft-section">
        <div className="container">
          <SectionHeading eyebrow="CAPABILITIES" title="What the work can include." />
          <div className="card-grid capability-grid">
            {area.capabilities.map((item, index) => (
              <Reveal className="content-card capability-card" key={item.title} delay={index % 3 === 1 ? "1" : index % 3 === 2 ? "2" : undefined}>
                <span className="card-index">{String(index + 1).padStart(2, "0")}</span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <section className="content-section">
        <div className="container tech-applications">
          <SectionHeading eyebrow="APPLICATIONS" title="Where it can be applied." />
          <ol className="application-list">
            {area.applications.map((item, index) => (
              <li key={item.title}>
                <span>{String(index + 1).padStart(2, "0")}</span>
                <div><h3>{item.title}</h3><p>{item.text}</p></div>
              </li>
            ))}
          </ol>
          <div className="tech-toolkit">
            <span className="tech-toolkit-label">TOOLS &amp; TECHNOLOGIES</span>
            <ul>{area.toolkit.map((tool) => <li key={tool}>{tool}</li>)}</ul>
          </div>
        </div>
      </section>
      <section className="content-section soft-section">
        <div className="container">
          <SectionHeading eyebrow="RELATED TECHNOLOGIES" title="Connected disciplines." />
          <div className="related-tech-grid">
            {technologyAreas.filter((other) => other.key !== technologyKey).slice(0, 3).map((other) => (
              <Link to={other.path} className="related-tech-card" key={other.key}>
                <span>{other.name}</span><ArrowUpRight aria-hidden="true" />
                <p>{other.description}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>
      <ContactBand title="Have a technology requirement?" summary="Let’s discuss the application, the constraints, and the right next step." />
    </>
  );
}

export function ServicesPage() {
  const steps = [
    { title: "Frame the problem", text: "Clarify the need, users, and constraints." },
    { title: "Shape the solution", text: "Choose a practical path across product, software, and devices." },
    { title: "Build and evaluate", text: "Develop, connect, and test against intended use." },
  ] as const;

  return (
    <>
      <PageHero
        eyebrow="OUR SERVICES"
        title="From connected ideas"
        highlight="to working solutions."
        summary="Product thinking, engineering, and integration for technology that has a clear job to do."
        image={media.heroServices}
        breadcrumbs={[{ label: "Services" }]}
      />
      <section className="content-section">
        <div className="container">
          <SectionHeading
            eyebrow="HOW WE HELP"
            title="A connected set of capabilities."
            summary="We bring the right disciplines together around a product or business need. The work can begin with an early concept, an existing system, or a workflow ready to improve."
          />
          <div className="process-grid">
            {steps.map((step, index) => (
              <Reveal key={step.title} className="process-step" delay={index === 1 ? "1" : index === 2 ? "2" : undefined}>
                <span>{String(index + 1).padStart(2, "0")}</span><h3>{step.title}</h3><p>{step.text}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <section className="content-section soft-section" id="services">
        <div className="container">
          <SectionHeading eyebrow="SERVICE CATEGORIES" title="Explore the capabilities." />
          <div className="card-grid service-grid">
            {serviceCategories.map((service, index) => (
              <Reveal key={service.title} className="content-card service-card" delay={index % 3 === 1 ? "1" : index % 3 === 2 ? "2" : undefined}>
                <span className="card-index">{String(index + 1).padStart(2, "0")}</span>
                <h3>{service.title}</h3>
                <p>{service.text}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <section className="content-section">
        <div className="container">
          <SectionHeading eyebrow="SECTORS" title="See where the work applies." />
          <ul className="chip-list chip-list-large">{companyDomains.map((domain) => <li key={domain}>{domain}</li>)}</ul>
        </div>
      </section>
      <ContactBand title="Bring us the challenge." summary="We’ll help shape a practical path around the need and its users." />
    </>
  );
}

export function PortfolioPage() {
  return (
    <>
      <PageHero
        eyebrow="OUR PORTFOLIO"
        title="Applied thinking."
        highlight="Practical outcomes."
        summary="A selection of project areas and solution themes represented in the material supplied for this website."
        image={media.heroProjects}
        breadcrumbs={[{ label: "Portfolio" }]}
      />
      <section className="content-section">
        <div className="container">
          <SectionHeading eyebrow="SELECTED PROJECT AREAS" title="A range of problems. One thoughtful process." />
          <div className="portfolio-grid">
            {portfolioProjects.map((project, index) => (
              <Reveal className="project-card" key={project.title} delay={index % 2 === 1 ? "1" : undefined}>
                <div className="project-image"><img src={project.image} alt={project.alt} loading="lazy" /></div>
                <div className="project-body">
                  <p className="project-category"><span>{String(index + 1).padStart(2, "0")}</span>{project.category}</p>
                  <h3>{project.title}</h3>
                  <p>{project.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
          <p className="source-note">The photographs are illustrative and are not client project screenshots. Project descriptions follow the supplied portfolio material; no outcome metrics or endorsements are claimed.</p>
          <Button asChild variant="outline" className="text-link-button">
            <Link to="/about/recognitions-milestones">Recognition and experience <ArrowRight aria-hidden="true" /></Link>
          </Button>
        </div>
      </section>
      <ContactBand title="Have a challenge to solve?" summary="Let’s start with a conversation about the work and the possibilities." />
    </>
  );
}

export function ContactPage() {
  return (
    <>
      <PageHero
        eyebrow="CONTACT US"
        title="Let’s turn your idea"
        highlight="into something real."
        summary="Tell us what you’re working on. We’ll start with a conversation about the challenge and the possibilities."
        image={media.heroServices}
        breadcrumbs={[{ label: "Contact" }]}
      />
      <section className="content-section contact-section">
        <div className="container contact-layout">
          <div className="contact-details">
            <SectionHeading eyebrow="START A CONVERSATION" title="What’s on your mind?" summary="Share a little about your project, product idea, or technology requirement." />
            <div className="contact-detail-list">
              <a href="mailto:info@cogniot.com"><span className="contact-detail-icon"><ArrowUpRight aria-hidden="true" /></span><span><small>EMAIL</small><strong>info@cogniot.com</strong></span></a>
              <div><span className="contact-detail-icon"><MapPin aria-hidden="true" /></span><span><small>LOCATION</small><strong>India</strong><span>{companyAddress}</span></span></div>
            </div>
          </div>
          <div className="contact-form-wrap">
            <h2>Tell us about your project</h2>
            <ContactForm />
          </div>
        </div>
      </section>
    </>
  );
}

export function CareersPage() {
  return (
    <>
      <PageHero
        eyebrow="CAREERS AT COGNIOT"
        title="Build what matters."
        highlight="Grow with purpose."
        summary="Bring curiosity, learn by doing, and contribute to technology shaped around meaningful problems."
        image={media.engineeringLab}
        breadcrumbs={[{ label: "Careers" }]}
      />
      <section className="content-section">
        <div className="container careers-intro">
          <div>
            <p className="eyebrow">YOUR NEXT STEP</p>
            <h2>A place to learn and contribute.</h2>
            <p>We welcome learners and professionals interested in software, IoT, product development, and digital solutions. Share the role you have in mind and the experience you bring.</p>
          </div>
          <div className="career-paths">
            <article><span>01 / LEARN</span><h3>Internship</h3><p>Project-oriented experience and guided learning.</p></article>
            <article><span>02 / CONTRIBUTE</span><h3>Job opportunities</h3><p>Share your profile for current or future roles.</p></article>
            <div className="career-interest"><strong>AREAS OF INTEREST</strong><p>Software · IoT · Product development · Web and mobile applications · Data and integration</p></div>
          </div>
        </div>
      </section>
      <section className="content-section soft-section">
        <div className="container career-form-layout">
          <div>
            <SectionHeading eyebrow="WORK WITH US" title="Tell us about yourself." summary="Choose an internship or job opportunity and share the experience you bring." />
            <p className="form-footnote">Résumé files are optional and stored privately.</p>
          </div>
          <div className="career-form-wrap"><CareerApplicationForm /></div>
        </div>
      </section>
      <ContactBand title="Bring your curiosity." summary="Let’s explore the fit." />
    </>
  );
}