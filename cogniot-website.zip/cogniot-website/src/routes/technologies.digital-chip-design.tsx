import { createFileRoute } from "@tanstack/react-router";

import { TechnologyDetailPage } from "@/components/site-pages";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/technologies/digital-chip-design")({
  head: () => ({
    meta: pageMeta(
      "Digital Chip Design | COGNIOT Technology",
      "Digital logic, FPGA prototyping, functional verification, and application-specific hardware design topics from COGNIOT.",
    ),
  }),
  component: DigitalChipDesignPage,
});

function DigitalChipDesignPage() {
  return <TechnologyDetailPage technologyKey="digital-chip-design" />;
}