import { useEffect, useRef, useState, type ReactNode } from "react";
import { Link, useLocation } from "@tanstack/react-router";
import { ArrowUpRight, ChevronDown, Menu, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { aboutNavigation, media, technologyNavigation } from "@/lib/site-content";

type RoutePath =
  | "/"
  | "/about/our-story"
  | "/about/vision-mission"
  | "/about/leadership-team"
  | "/about/recognitions-milestones"
  | "/about/clients-partners"
  | "/technologies"
  | "/technologies/ai-saas"
  | "/technologies/iot"
  | "/technologies/5g-6g"
  | "/technologies/digital-chip-design"
  | "/services"
  | "/portfolio"
  | "/careers"
  | "/contact";

const DESKTOP_HOVER_QUERY = "(hover: hover) and (min-width: 1081px)";

const simpleNavigation: { label: string; path: RoutePath }[] = [
  { label: "Services", path: "/services" },
  { label: "Portfolio", path: "/portfolio" },
  { label: "Careers", path: "/careers" },
  { label: "Contact", path: "/contact" },
];

function activeClass(pathname: string, to: string) {
  return pathname === to || (to !== "/" && pathname.startsWith(`${to}/`)) ? "is-current" : "";
}

export function SiteHeader() {
  const location = useLocation();
  const headerRef = useRef<HTMLElement>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [expandedMenu, setExpandedMenu] = useState<"about" | "technology" | null>(null);

  useEffect(() => {
    setMobileOpen(false);
    setExpandedMenu(null);
  }, [location.pathname]);

  useEffect(() => {
    if (!mobileOpen && !expandedMenu) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setMobileOpen(false);
        setExpandedMenu(null);
      }
    };
    const closeOnOutsideClick = (event: PointerEvent) => {
      if (event.target instanceof Node && !headerRef.current?.contains(event.target)) {
        setMobileOpen(false);
        setExpandedMenu(null);
      }
    };
    document.addEventListener("keydown", closeOnEscape);
    document.addEventListener("pointerdown", closeOnOutsideClick);
    return () => {
      document.removeEventListener("keydown", closeOnEscape);
      document.removeEventListener("pointerdown", closeOnOutsideClick);
    };
  }, [expandedMenu, mobileOpen]);

  const closeMenus = () => {
    setMobileOpen(false);
    setExpandedMenu(null);
  };

  const canHover = () =>
    typeof window !== "undefined" && window.matchMedia(DESKTOP_HOVER_QUERY).matches;
  const hoverOpen = (menu: "about" | "technology") => () => {
    if (canHover()) setExpandedMenu(menu);
  };
  const hoverClose = () => {
    if (canHover()) setExpandedMenu(null);
  };

  return (
    <header className="site-header" ref={headerRef}>
      <a className="skip-link" href="#main-content">
        Skip to content
      </a>
      <div className="container header-inner">
        <Link to="/" aria-label="COGNIOT Technology home" className="site-brand" onClick={closeMenus}>
          <img src={media.logo} alt="COGNIOT Technology" />
        </Link>

        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="mobile-menu-toggle"
          aria-label={mobileOpen ? "Close navigation" : "Open navigation"}
          aria-expanded={mobileOpen}
          aria-controls="primary-navigation"
          onClick={() => setMobileOpen((open) => !open)}
        >
          {mobileOpen ? <X aria-hidden="true" /> : <Menu aria-hidden="true" />}
        </Button>

        <nav
          id="primary-navigation"
          className={`site-nav${mobileOpen ? " is-open" : ""}`}
          aria-label="Primary navigation"
          aria-hidden={!mobileOpen && undefined}
        >
          <Link to="/" className={`nav-link ${activeClass(location.pathname, "/")}`} onClick={closeMenus}>
            Home
          </Link>

          <div
            className={`nav-entry${expandedMenu === "about" ? " is-expanded" : ""}`}
            onMouseEnter={hoverOpen("about")}
            onMouseLeave={hoverClose}
          >
            <Link
              to="/about/our-story"
              className={`nav-link ${activeClass(location.pathname, "/about")}`}
              onClick={closeMenus}
            >
              About Us
            </Link>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="nav-dropdown-toggle"
              aria-label="Show About Us pages"
              aria-expanded={expandedMenu === "about"}
              aria-controls="about-navigation"
              onClick={() => setExpandedMenu((current) => current === "about" ? null : "about")}
            >
              <ChevronDown aria-hidden="true" />
            </Button>
            <div id="about-navigation" className="nav-panel" hidden={expandedMenu !== "about"}>
              {aboutNavigation.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={location.pathname === item.path ? "is-current" : undefined}
                  aria-current={location.pathname === item.path ? "page" : undefined}
                  onClick={closeMenus}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </div>

          <div
            className={`nav-entry${expandedMenu === "technology" ? " is-expanded" : ""}`}
            onMouseEnter={hoverOpen("technology")}
            onMouseLeave={hoverClose}
          >
            <Link
              to="/technologies"
              className={`nav-link ${activeClass(location.pathname, "/technologies")}`}
              onClick={closeMenus}
            >
              Technologies
            </Link>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="nav-dropdown-toggle"
              aria-label="Show technology pages"
              aria-expanded={expandedMenu === "technology"}
              aria-controls="technology-navigation"
              onClick={() => setExpandedMenu((current) => current === "technology" ? null : "technology")}
            >
              <ChevronDown aria-hidden="true" />
            </Button>
            <div id="technology-navigation" className="nav-panel" hidden={expandedMenu !== "technology"}>
              {technologyNavigation.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={location.pathname === item.path ? "is-current" : undefined}
                  aria-current={location.pathname === item.path ? "page" : undefined}
                  onClick={closeMenus}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </div>

          {simpleNavigation.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`nav-link ${activeClass(location.pathname, item.path)}`}
              onClick={closeMenus}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <Button asChild className="header-talk">
          <Link to="/contact" onClick={closeMenus}>
            Let’s talk <ArrowUpRight aria-hidden="true" />
          </Link>
        </Button>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="container footer-main">
        <div className="footer-brand-block">
          <Link to="/" aria-label="COGNIOT Technology home" className="footer-brand">
            <img src={media.logo} alt="COGNIOT Technology" />
          </Link>
          <p>Building connected products, purposeful software, and digital solutions.</p>
        </div>
        <div className="footer-column">
          <h2>About COGNIOT</h2>
          <Link to="/about/our-story">Our Story</Link>
          <Link to="/about/vision-mission">Vision &amp; Mission</Link>
          <Link to="/about/leadership-team">Leadership &amp; Team</Link>
          <Link to="/about/recognitions-milestones">Recognitions</Link>
          <Link to="/about/clients-partners">Clients &amp; Partners</Link>
        </div>
        <div className="footer-column">
          <h2>Explore</h2>
          <Link to="/services">Services</Link>
          <Link to="/technologies">Technologies</Link>
          <Link to="/portfolio">Portfolio</Link>
          <Link to="/careers">Careers</Link>
        </div>
        <div className="footer-column footer-contact">
          <h2>Start a conversation</h2>
          <Link to="/contact">Contact COGNIOT <ArrowUpRight aria-hidden="true" /></Link>
          <a href="mailto:info@cogniot.com">info@cogniot.com</a>
          <p>Kovilpatti, Thoothukudi, Tamil Nadu</p>
        </div>
      </div>
      <div className="footer-bottom">
        <div className="container footer-bottom-inner">
          <span>© {new Date().getFullYear()} COGNIOT TECHNOLOGY PRIVATE LIMITED</span>
          <span>Next Generation Technology</span>
        </div>
      </div>
    </footer>
  );
}

export interface BreadcrumbItem {
  label: string;
  to?: RoutePath;
}

export function PageHero({
  eyebrow,
  title,
  highlight,
  summary,
  image,
  breadcrumbs,
}: {
  eyebrow: string;
  title: string;
  highlight?: string;
  summary: string;
  image: string;
  breadcrumbs: readonly BreadcrumbItem[];
}) {
  return (
    <section className="page-hero">
      <div className="page-hero-media" aria-hidden="true">
        <img src={image} alt="" />
      </div>
      <div className="container page-hero-content">
        <nav className="breadcrumbs" aria-label="Breadcrumb">
          <ol>
            <li><Link to="/">Home</Link></li>
            {breadcrumbs.map((crumb) => (
              <li key={`${crumb.label}-${crumb.to ?? "current"}`}>
                {crumb.to ? <Link to={crumb.to}>{crumb.label}</Link> : <span aria-current="page">{crumb.label}</span>}
              </li>
            ))}
          </ol>
        </nav>
        <p className="eyebrow page-eyebrow">{eyebrow}</p>
        <h1>
          {title}
          {highlight ? <span className="hero-highlight"> {highlight}</span> : null}
        </h1>
        <p className="page-hero-summary">{summary}</p>
      </div>
    </section>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  summary,
  className = "",
}: {
  eyebrow: string;
  title: string;
  summary?: string;
  className?: string;
}) {
  return (
    <div className={`section-heading ${className}`}>
      <p className="eyebrow">{eyebrow}</p>
      <h2>{title}</h2>
      {summary ? <p>{summary}</p> : null}
    </div>
  );
}

export function Reveal({
  children,
  className = "",
  delay,
}: {
  children: ReactNode;
  className?: string;
  delay?: "1" | "2" | "3" | undefined;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    document.documentElement.dataset["motionReady"] = "true";
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || !("IntersectionObserver" in window)) {
      element.classList.add("is-visible");
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      }
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} data-reveal="" data-reveal-delay={delay} className={className}>
      {children}
    </div>
  );
}

export function CountUp({ value, suffix, label }: { value: number; suffix: string; label: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const formattedValue = new Intl.NumberFormat("en-US").format(value);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    const renderValue = (amount: number) => {
      element.textContent = `${new Intl.NumberFormat("en-US").format(amount)}${suffix}`;
    };
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || !("IntersectionObserver" in window)) {
      renderValue(value);
      return;
    }
    let frame = 0;
    let startTime: number | null = null;
    const step = (time: number) => {
      if (startTime === null) startTime = time;
      const progress = Math.min((time - startTime) / 1100, 1);
      renderValue(Math.round(value * (1 - Math.pow(1 - progress, 3))));
      if (progress < 1) frame = window.requestAnimationFrame(step);
    };
    const observer = new IntersectionObserver((entries) => {
      if (entries.some((entry) => entry.isIntersecting)) {
        frame = window.requestAnimationFrame(step);
        observer.disconnect();
      }
    }, { threshold: 0.2 });
    observer.observe(element);
    return () => {
      observer.disconnect();
      window.cancelAnimationFrame(frame);
    };
  }, [suffix, value]);

  return (
    <div className="stat-card">
      <span ref={ref} className="stat-value" aria-label={`${formattedValue}${suffix}`}>
        {formattedValue}{suffix}
      </span>
      <span className="stat-label">{label}</span>
    </div>
  );
}

export function Timeline({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLOListElement>(null);
  const [active, setActive] = useState(false);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || !("IntersectionObserver" in window)) {
      setActive(true);
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      if (entries.some((entry) => entry.isIntersecting)) {
        setActive(true);
        observer.disconnect();
      }
    }, { threshold: 0.1 });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  return <ol ref={ref} className={`timeline${active ? " is-active" : ""}`}>{children}</ol>;
}

export function ContactBand({
  title = "Let’s build something meaningful together.",
  summary = "Tell us what you’re working on. We’ll start with a conversation about the challenge and the possibilities.",
}: {
  title?: string;
  summary?: string;
}) {
  return (
    <section className="contact-band">
      <div className="container contact-band-inner">
        <div>
          <p className="eyebrow">HAVE A PROJECT IN MIND?</p>
          <h2>{title}</h2>
          <p>{summary}</p>
        </div>
        <Button asChild variant="secondary" className="contact-band-button">
          <Link to="/contact">Start a conversation <ArrowUpRight aria-hidden="true" /></Link>
        </Button>
      </div>
    </section>
  );
}