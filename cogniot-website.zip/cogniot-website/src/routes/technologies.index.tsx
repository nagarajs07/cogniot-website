import { createFileRoute } from "@tanstack/react-router";

import { TechnologiesOverviewPage } from "@/components/site-pages";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/technologies/")({
  head: () => ({
    meta: pageMeta(
      "Technologies | COGNIOT Technology",
      "Explore COGNIOT’s connected work across AI and SaaS, IoT, next-generation connectivity, and digital chip design.",
    ),
  }),
  component: TechnologiesOverviewPage,
});