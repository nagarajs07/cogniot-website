import { useState, type FormEvent } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ArrowUpRight, Paperclip } from "lucide-react";

import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { contactServiceOptions } from "@/lib/site-content";
import { submitCareerApplication, submitContact } from "@/lib/submissions.functions";

type FormStatus = { kind: "success" | "error"; message: string } | null;

function StatusMessage({ status }: { status: FormStatus }) {
  if (!status) return null;
  return <p className={`form-status ${status.kind}`} role="status" aria-live="polite">{status.message}</p>;
}

export function ContactForm() {
  const submit = useServerFn(submitContact);
  const [status, setStatus] = useState<FormStatus>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setStatus(null);
    const form = event.currentTarget;
    const values = new FormData(form);
    try {
      const result = await submit({
        data: {
          fullName: String(values.get("fullName") ?? ""),
          companyName: String(values.get("companyName") ?? ""),
          email: String(values.get("email") ?? ""),
          phone: String(values.get("phone") ?? ""),
          serviceInterest: String(values.get("serviceInterest") ?? "") as (typeof contactServiceOptions)[number],
          projectDescription: String(values.get("projectDescription") ?? ""),
          website: String(values.get("website") ?? ""),
        },
      });
      setStatus({ kind: result.ok ? "success" : "error", message: result.message });
      if (result.ok) form.reset();
    } catch {
      setStatus({ kind: "error", message: "Your enquiry could not be sent. Please try again." });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form className="site-form" onSubmit={handleSubmit}>
      <div className="form-grid">
        <label className="field">
          <span>Full name <b aria-hidden="true">*</b></span>
          <input name="fullName" type="text" autoComplete="name" minLength={2} maxLength={120} required />
        </label>
        <label className="field">
          <span>Company</span>
          <input name="companyName" type="text" autoComplete="organization" maxLength={160} />
        </label>
        <label className="field">
          <span>Email address <b aria-hidden="true">*</b></span>
          <input name="email" type="email" autoComplete="email" maxLength={254} required />
        </label>
        <label className="field">
          <span>Phone number <b aria-hidden="true">*</b></span>
          <input name="phone" type="tel" autoComplete="tel" minLength={5} maxLength={50} required />
        </label>
        <label className="field field-wide">
          <span>Service interest <b aria-hidden="true">*</b></span>
          <select name="serviceInterest" defaultValue="" required>
            <option value="" disabled>Choose a service</option>
            {contactServiceOptions.map((service) => <option key={service} value={service}>{service}</option>)}
          </select>
        </label>
        <label className="field field-wide">
          <span>Tell us about your project <b aria-hidden="true">*</b></span>
          <textarea name="projectDescription" rows={5} minLength={10} maxLength={4000} required />
        </label>
      </div>
      <label className="honeypot" aria-hidden="true">
        Website <input name="website" tabIndex={-1} autoComplete="off" />
      </label>
      <div className="form-submit-row">
        <Button type="submit" disabled={submitting}>
          {submitting ? "Sending…" : "Send enquiry"} <ArrowUpRight aria-hidden="true" />
        </Button>
        <span className="form-footnote">Your details are kept private.</span>
      </div>
      <StatusMessage status={status} />
    </form>
  );
}

function validateResumeFile(file: File) {
  if (file.size > 10_000_000) return "Please choose a résumé no larger than 10 MB.";
  const lowerName = file.name.toLowerCase();
  const isPdf = lowerName.endsWith(".pdf");
  const isDocx = lowerName.endsWith(".docx");
  const expectedMime = isPdf
    ? "application/pdf"
    : "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
  if ((!isPdf && !isDocx) || (file.type && file.type !== expectedMime)) {
    return "Please upload a PDF or DOCX résumé.";
  }
  return null;
}

export function CareerApplicationForm() {
  const submit = useServerFn(submitCareerApplication);
  const [status, setStatus] = useState<FormStatus>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setStatus(null);
    const form = event.currentTarget;
    const values = new FormData(form);
    const trapValue = String(values.get("website") ?? "");
    const resumeInput = form.elements.namedItem("resume");
    const resume = resumeInput instanceof HTMLInputElement ? resumeInput.files?.item(0) ?? null : null;
    const rawType = String(values.get("applicationType") ?? "internship");
    const applicationType = rawType === "general" ? "general" : "internship";
    let resumePath: string | null = null;

    try {
      if (resume && !trapValue) {
        const validationError = validateResumeFile(resume);
        if (validationError) {
          setStatus({ kind: "error", message: validationError });
          setSubmitting(false);
          return;
        }
        const isPdf = resume.name.toLowerCase().endsWith(".pdf");
        const header = new Uint8Array(await resume.slice(0, isPdf ? 5 : 4).arrayBuffer());
        const signatureIsValid = isPdf
          ? header[0] === 0x25 && header[1] === 0x50 && header[2] === 0x44 && header[3] === 0x46 && header[4] === 0x2d
          : header[0] === 0x50 && header[1] === 0x4b && header[2] === 0x03 && header[3] === 0x04;
        if (!signatureIsValid) {
          setStatus({ kind: "error", message: "The résumé file does not match its selected format." });
          setSubmitting(false);
          return;
        }
        const extension = isPdf ? "pdf" : "docx";
        resumePath = `${crypto.randomUUID()}.${extension}`;
        const contentType = isPdf
          ? "application/pdf"
          : "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        const { error: uploadError } = await supabase.storage
          .from("career-resumes")
          .upload(resumePath, resume, { contentType, cacheControl: "0", upsert: false });
        if (uploadError) {
          setStatus({ kind: "error", message: "The résumé upload could not be saved. Please try again." });
          setSubmitting(false);
          return;
        }
      }

      const result = await submit({
        data: {
          fullName: String(values.get("fullName") ?? ""),
          email: String(values.get("email") ?? ""),
          phone: String(values.get("phone") ?? ""),
          positionApplyingFor: String(values.get("positionApplyingFor") ?? ""),
          qualification: String(values.get("qualification") ?? ""),
          applicationType,
          message: String(values.get("message") ?? ""),
          resumePath,
          website: trapValue,
        },
      });
      setStatus({ kind: result.ok ? "success" : "error", message: result.message });
      if (result.ok) form.reset();
    } catch {
      setStatus({ kind: "error", message: "Your application could not be sent. Please try again." });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form className="site-form" onSubmit={handleSubmit}>
      <div className="form-grid">
        <label className="field">
          <span>Full name <b aria-hidden="true">*</b></span>
          <input name="fullName" type="text" autoComplete="name" minLength={2} maxLength={120} required />
        </label>
        <label className="field">
          <span>Email address <b aria-hidden="true">*</b></span>
          <input name="email" type="email" autoComplete="email" maxLength={254} required />
        </label>
        <label className="field">
          <span>Phone number <b aria-hidden="true">*</b></span>
          <input name="phone" type="tel" autoComplete="tel" minLength={5} maxLength={50} required />
        </label>
        <label className="field">
          <span>Position of interest <b aria-hidden="true">*</b></span>
          <input name="positionApplyingFor" type="text" minLength={2} maxLength={160} placeholder="e.g. Product engineering" required />
        </label>
        <label className="field">
          <span>Qualification <b aria-hidden="true">*</b></span>
          <input name="qualification" type="text" minLength={2} maxLength={160} required />
        </label>
        <label className="field">
          <span>Application type <b aria-hidden="true">*</b></span>
          <select name="applicationType" defaultValue="internship" required>
            <option value="internship">Internship</option>
            <option value="general">Job opportunity</option>
          </select>
        </label>
        <label className="field field-wide">
          <span>Tell us about yourself <b aria-hidden="true">*</b></span>
          <textarea name="message" rows={5} minLength={10} maxLength={4000} required />
        </label>
        <label className="field field-wide resume-field">
          <span className="resume-label"><Paperclip aria-hidden="true" /> Résumé <small>PDF or DOCX, up to 10 MB</small></span>
          <input name="resume" type="file" accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document" />
        </label>
      </div>
      <label className="honeypot" aria-hidden="true">
        Website <input name="website" tabIndex={-1} autoComplete="off" />
      </label>
      <div className="form-submit-row">
        <Button type="submit" disabled={submitting}>
          {submitting ? "Sending…" : "Submit application"} <ArrowUpRight aria-hidden="true" />
        </Button>
        <span className="form-footnote">Résumé files are stored privately.</span>
      </div>
      <StatusMessage status={status} />
    </form>
  );
}