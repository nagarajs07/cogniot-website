import { createFileRoute } from "@tanstack/react-router";

import { LeadershipTeamPage } from "@/components/site-pages";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/about/leadership-team")({
  head: () => ({
    meta: pageMeta(
      "Leadership & Team | COGNIOT Technology",
      "Meet the multidisciplinary team behind COGNIOT’s IoT product development, software engineering, and system integration work.",
    ),
  }),
  component: LeadershipTeamPage,
});