import { createFileRoute } from "@tanstack/react-router";

import { TechnologyDetailPage } from "@/components/site-pages";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/technologies/iot")({
  head: () => ({
    meta: pageMeta(
      "Internet of Things (IoT) | COGNIOT Technology",
      "Explore COGNIOT’s connected devices, sensors, embedded controllers, wireless connectivity, analytics, and IoT applications.",
    ),
  }),
  component: IoTPage,
});

function IoTPage() {
  return <TechnologyDetailPage technologyKey="iot" />;
}