import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const websiteTrap = z.string().max(200).optional();

const contactSchema = z.object({
  fullName: z.string().trim().min(2).max(120),
  companyName: z.string().trim().max(160).optional(),
  email: z.string().trim().email().max(254),
  phone: z.string().trim().min(5).max(50),
  serviceInterest: z.enum([
    "IoT product development",
    "Software development",
    "Web application development",
    "Mobile application development",
    "Hardware product development",
    "Product design and testing",
    "AI and data analytics",
    "System integration",
    "Technology consulting",
    "Other",
  ]),
  projectDescription: z.string().trim().min(10).max(4000),
  website: websiteTrap,
});

const careerSchema = z.object({
  fullName: z.string().trim().min(2).max(120),
  email: z.string().trim().email().max(254),
  phone: z.string().trim().min(5).max(50),
  positionApplyingFor: z.string().trim().min(2).max(160),
  qualification: z.string().trim().min(2).max(160),
  applicationType: z.enum(["internship", "general"]),
  message: z.string().trim().min(10).max(4000),
  resumePath: z.string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\.(pdf|docx)$/i).nullable().optional(),
  website: websiteTrap,
});

function isValidResume(bytes: Uint8Array, path: string) {
  if (bytes.length > 10_000_000) return false;
  const isPdf = path.endsWith(".pdf") && bytes.length >= 5 &&
    bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46 && bytes[4] === 0x2d;
  const isDocx = path.endsWith(".docx") && bytes.length >= 4 &&
    bytes[0] === 0x50 && bytes[1] === 0x4b && bytes[2] === 0x03 && bytes[3] === 0x04;
  return isPdf || isDocx;
}

export const submitContact = createServerFn({ method: "POST" })
  .inputValidator((input) => contactSchema.parse(input))
  .handler(async ({ data }) => {
    if (data.website) return { ok: true, message: "Thank you. Your enquiry has been received." };

    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const { error } = await supabaseAdmin.from("contact_submissions").insert({
        full_name: data.fullName,
        company_name: data.companyName || null,
        email: data.email,
        phone: data.phone,
        service_interest: data.serviceInterest,
        project_description: data.projectDescription,
      });
      if (error) {
        console.error("[contact-submission] Storage failed.");
        return { ok: false, message: "Your enquiry could not be sent. Please try again." };
      }
      return { ok: true, message: "Thank you. Your enquiry has been received." };
    } catch {
      console.error("[contact-submission] Storage failed.");
      return { ok: false, message: "Your enquiry could not be sent. Please try again." };
    }
  });

export const submitCareerApplication = createServerFn({ method: "POST" })
  .inputValidator((input) => careerSchema.parse(input))
  .handler(async ({ data }) => {
    if (data.website) return { ok: true, message: "Thank you. Your application has been received." };

    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const resumePath = data.resumePath ?? null;
      if (resumePath) {
        const { data: resume, error: downloadError } = await supabaseAdmin.storage
          .from("career-resumes")
          .download(resumePath);
        if (downloadError || !resume) {
          return { ok: false, message: "The résumé upload could not be checked. Please try again." };
        }
        const bytes = new Uint8Array(await resume.arrayBuffer());
        if (!isValidResume(bytes, resumePath)) {
          await supabaseAdmin.storage.from("career-resumes").remove([resumePath]);
          return { ok: false, message: "Please upload a valid PDF or DOCX résumé under 10 MB." };
        }
      }

      const { error } = await supabaseAdmin.from("career_applications").insert({
        full_name: data.fullName,
        email: data.email,
        phone: data.phone,
        position_applying_for: data.positionApplyingFor,
        qualification: data.qualification,
        application_type: data.applicationType,
        message: data.message,
        resume_path: resumePath,
      });
      if (error) {
        if (resumePath) await supabaseAdmin.storage.from("career-resumes").remove([resumePath]);
        console.error("[career-application] Storage failed.");
        return { ok: false, message: "Your application could not be sent. Please try again." };
      }
      return { ok: true, message: "Thank you. Your application has been received." };
    } catch {
      console.error("[career-application] Storage failed.");
      return { ok: false, message: "Your application could not be sent. Please try again." };
    }
  });