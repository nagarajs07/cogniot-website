import { createFileRoute } from "@tanstack/react-router";

import { ClientsPartnersPage } from "@/components/site-pages";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/about/clients-partners")({
  head: () => ({
    meta: pageMeta(
      "Our Clients & Partners | COGNIOT Technology",
      "See the organisations, client testimonials, and ecosystem programmes represented in COGNIOT’s source materials.",
    ),
  }),
  component: ClientsPartnersPage,
});