import { createFileRoute } from "@tanstack/react-router";

import { ContactPage } from "@/components/site-pages";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: pageMeta(
      "Contact COGNIOT | Start a Conversation",
      "Contact COGNIOT Technology about a product idea, technology requirement, or digital project.",
    ),
  }),
  component: ContactPage,
});