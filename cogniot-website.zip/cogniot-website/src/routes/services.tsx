import { createFileRoute } from "@tanstack/react-router";

import { ServicesPage } from "@/components/site-pages";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: pageMeta(
      "Technology Services | COGNIOT Technology",
      "Product thinking, IoT, software, application development, testing, and system integration from COGNIOT Technology.",
    ),
  }),
  component: ServicesPage,
});