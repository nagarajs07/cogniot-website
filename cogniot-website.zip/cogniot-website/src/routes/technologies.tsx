import { Outlet, createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/technologies")({
  component: TechnologiesLayout,
});

function TechnologiesLayout() {
  return <Outlet />;
}