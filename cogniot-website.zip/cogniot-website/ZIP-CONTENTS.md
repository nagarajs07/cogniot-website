# COGNIOT Technology — Website ZIP Contents

Everything in this archive is the full website source: all code, styles, images,
config, and the database table definitions.

## What is inside

| Folder / file | What it holds |
|---|---|
| `src/` | All website code. Pages are in `src/routes/`, shared parts in `src/components/`, text and links in `src/lib/site-content.ts`, styles in `src/styles.css`. |
| `src/assets/cogniot/` | Image pointers the live site uses (small `.asset.json` files that point to the hosted copies). |
| `images/` | The 18 real picture files (logo, banner photos, client logos, certificates) as normal `.jpg` / `.png` files. |
| `public/` | Site icon (`favicon.ico`) and `robots.txt`. |
| `drizzle/` | Database table definitions and the SQL that creates the contact + careers form tables. |
| `supabase/config.toml` | Backend configuration. |
| `.env` | Backend connection settings. These are the public connection values only — no private keys are in this file. |
| `package.json`, `bun.lock` | The list of libraries the site needs, and the exact locked versions. |
| `vite.config.ts`, `tsconfig.json`, `vitest.config.ts`, `eslint.config.js`, `components.json`, `.prettierrc` | Build, TypeScript, test, and code-format settings. |
| `AGENTS.md`, `README.md` | Project notes. |

## About .aspx files

This site is not an ASP.NET site, so there are no `.aspx` files anywhere.
The pages are written in React with TypeScript, so the page files are `.tsx`
files under `src/routes/`. There are 15 pages in total.

## Running the site on your own computer

1. Install Bun (https://bun.sh).
2. Unzip this archive and open the `cogniot-website` folder in a terminal.
3. Run `bun install` — this downloads the libraries listed in `package.json`.
4. Run `bun run dev` — the site then opens at http://localhost:8080.

The contact and careers forms save into the backend that `.env` points at.
That backend lives with the hosted project, so the forms work from this copy
without any extra setup.

## Not included (and why)

- `node_modules/` — the downloaded libraries. `bun install` recreates them.
- `dist/`, `.tanstack/`, `.oj-cache/`, `tsconfig.tsbuildinfo` — build output and caches, regenerated automatically.
- `.git/` — the project's version history.
