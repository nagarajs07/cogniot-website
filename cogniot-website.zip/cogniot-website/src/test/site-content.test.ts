import { describe, expect, it } from "vitest";

import {
  aboutNavigation,
  CAROUSEL_INTERVAL_MS,
  homeSlides,
  PRIMARY_NAV_LABELS,
  technologyNavigation,
} from "@/lib/site-content";

describe("COGNIOT website requirements", () => {
  it("keeps the four-slide home carousel on a three-second interval", () => {
    expect(homeSlides).toHaveLength(4);
    expect(CAROUSEL_INTERVAL_MS).toBe(3000);
  });

  it("keeps the primary navigation in the requested order", () => {
    expect(PRIMARY_NAV_LABELS).toEqual([
      "Home",
      "About Us",
      "Technologies",
      "Services",
      "Portfolio",
      "Careers",
      "Contact",
    ]);
  });

  it("keeps every About Us and Technologies item on its own page", () => {
    expect(aboutNavigation.map((item) => item.path)).toEqual([
      "/about/our-story",
      "/about/vision-mission",
      "/about/leadership-team",
      "/about/recognitions-milestones",
      "/about/clients-partners",
    ]);
    expect(technologyNavigation.map((item) => item.path)).toEqual([
      "/technologies/ai-saas",
      "/technologies/iot",
      "/technologies/5g-6g",
      "/technologies/digital-chip-design",
    ]);
  });
});