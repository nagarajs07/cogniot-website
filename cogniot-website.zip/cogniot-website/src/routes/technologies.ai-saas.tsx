import { createFileRoute } from "@tanstack/react-router";

import { TechnologyDetailPage } from "@/components/site-pages";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/technologies/ai-saas")({
  head: () => ({
    meta: pageMeta(
      "AI & SaaS | COGNIOT Technology",
      "Data analytics, AI-assisted insight, cloud software, workflow automation, integrations, and application areas from COGNIOT.",
    ),
  }),
  component: AISaaSPage,
});

function AISaaSPage() {
  return <TechnologyDetailPage technologyKey="ai-saas" />;
}