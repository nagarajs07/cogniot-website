import { createFileRoute } from "@tanstack/react-router";

import { VisionMissionPage } from "@/components/site-pages";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/about/vision-mission")({
  head: () => ({
    meta: pageMeta(
      "Vision & Mission | COGNIOT Technology",
      "Explore COGNIOT’s official vision, mission commitments, and company values.",
    ),
  }),
  component: VisionMissionPage,
});