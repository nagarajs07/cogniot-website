import { createFileRoute } from "@tanstack/react-router";

import { OurStoryPage } from "@/components/site-pages";
import { pageMeta } from "@/lib/seo";

export const Route = createFileRoute("/about/our-story")({
  head: () => ({
    meta: pageMeta(
      "Our Story | COGNIOT Technology",
      "Learn how COGNIOT Technology grew from Kovilpatti, Tamil Nadu, with a focus on IoT products and software services.",
    ),
  }),
  component: OurStoryPage,
});